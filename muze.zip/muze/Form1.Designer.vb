﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.finish = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1.SuspendLayout()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = Global.muze.My.Resources.Resources._3647_389171567809707_842966703_n
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.Panel1.Controls.Add(Me.MenuStrip1)
        Me.Panel1.Controls.Add(Me.finish)
        Me.Panel1.Controls.Add(Me.Label38)
        Me.Panel1.Controls.Add(Me.Label39)
        Me.Panel1.Controls.Add(Me.Label37)
        Me.Panel1.Controls.Add(Me.Label36)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.Label34)
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.Label31)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.Label27)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(4, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(657, 507)
        Me.Panel1.TabIndex = 0
        '
        'finish
        '
        Me.finish.AutoSize = True
        Me.finish.Font = New System.Drawing.Font("Mistral", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.finish.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.finish.Location = New System.Drawing.Point(541, 444)
        Me.finish.Name = "finish"
        Me.finish.Size = New System.Drawing.Size(85, 38)
        Me.finish.TabIndex = 40
        Me.finish.Text = "finish"
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.Color.ForestGreen
        Me.Label38.Location = New System.Drawing.Point(410, 444)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(101, 13)
        Me.Label38.TabIndex = 39
        '
        'Label39
        '
        Me.Label39.BackColor = System.Drawing.Color.ForestGreen
        Me.Label39.Location = New System.Drawing.Point(337, 373)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(174, 22)
        Me.Label39.TabIndex = 38
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.ForestGreen
        Me.Label37.Location = New System.Drawing.Point(434, 409)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(88, 15)
        Me.Label37.TabIndex = 36
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.ForestGreen
        Me.Label36.Location = New System.Drawing.Point(300, 373)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(23, 100)
        Me.Label36.TabIndex = 35
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.Color.ForestGreen
        Me.Label35.Location = New System.Drawing.Point(494, 207)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(17, 166)
        Me.Label35.TabIndex = 34
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.ForestGreen
        Me.Label34.Location = New System.Drawing.Point(193, 373)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(23, 100)
        Me.Label34.TabIndex = 33
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.ForestGreen
        Me.Label33.Location = New System.Drawing.Point(532, 198)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(23, 100)
        Me.Label33.TabIndex = 32
        '
        'Label32
        '
        Me.Label32.BackColor = System.Drawing.Color.ForestGreen
        Me.Label32.Location = New System.Drawing.Point(448, 198)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(23, 100)
        Me.Label32.TabIndex = 31
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.Color.ForestGreen
        Me.Label31.Location = New System.Drawing.Point(136, 311)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(23, 84)
        Me.Label31.TabIndex = 30
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.ForestGreen
        Me.Label30.Location = New System.Drawing.Point(2, 409)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(23, 72)
        Me.Label30.TabIndex = 29
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.ForestGreen
        Me.Label29.Location = New System.Drawing.Point(172, 186)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(15, 126)
        Me.Label29.TabIndex = 28
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.ForestGreen
        Me.Label28.Location = New System.Drawing.Point(207, 207)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(23, 100)
        Me.Label28.TabIndex = 27
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.ForestGreen
        Me.Label27.Location = New System.Drawing.Point(2, 319)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(23, 100)
        Me.Label27.TabIndex = 26
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.ForestGreen
        Me.Label26.Location = New System.Drawing.Point(470, 24)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(23, 100)
        Me.Label26.TabIndex = 25
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.ForestGreen
        Me.Label25.Location = New System.Drawing.Point(64, 193)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(16, 100)
        Me.Label25.TabIndex = 24
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.ForestGreen
        Me.Label24.Location = New System.Drawing.Point(193, 56)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(23, 100)
        Me.Label24.TabIndex = 23
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.ForestGreen
        Me.Label23.Location = New System.Drawing.Point(304, 33)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(23, 100)
        Me.Label23.TabIndex = 22
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.ForestGreen
        Me.Label22.Location = New System.Drawing.Point(343, 26)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(23, 120)
        Me.Label22.TabIndex = 21
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.ForestGreen
        Me.Label21.Location = New System.Drawing.Point(7, 174)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(23, 91)
        Me.Label21.TabIndex = 20
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.ForestGreen
        Me.Label20.Location = New System.Drawing.Point(157, 32)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(23, 85)
        Me.Label20.TabIndex = 19
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.ForestGreen
        Me.Label19.Location = New System.Drawing.Point(134, 174)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(23, 91)
        Me.Label19.TabIndex = 18
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.ForestGreen
        Me.Label18.Location = New System.Drawing.Point(7, 56)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(119, 18)
        Me.Label18.TabIndex = 17
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.ForestGreen
        Me.Label17.Location = New System.Drawing.Point(448, 177)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(107, 21)
        Me.Label17.TabIndex = 16
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.ForestGreen
        Me.Label16.Location = New System.Drawing.Point(319, 444)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(101, 13)
        Me.Label16.TabIndex = 15
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.ForestGreen
        Me.Label15.Location = New System.Drawing.Point(214, 373)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(132, 22)
        Me.Label15.TabIndex = 14
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.ForestGreen
        Me.Label14.Location = New System.Drawing.Point(518, 409)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(88, 15)
        Me.Label14.TabIndex = 13
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.ForestGreen
        Me.Label13.Location = New System.Drawing.Point(374, 298)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(97, 26)
        Me.Label13.TabIndex = 12
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.ForestGreen
        Me.Label12.Location = New System.Drawing.Point(24, 335)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(102, 18)
        Me.Label12.TabIndex = 11
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.ForestGreen
        Me.Label11.Location = New System.Drawing.Point(64, 395)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(95, 19)
        Me.Label11.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.ForestGreen
        Me.Label10.Location = New System.Drawing.Point(67, 454)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 19)
        Me.Label10.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.ForestGreen
        Me.Label9.Location = New System.Drawing.Point(343, 146)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 21)
        Me.Label9.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.ForestGreen
        Me.Label8.Location = New System.Drawing.Point(64, 286)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(112, 26)
        Me.Label8.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.ForestGreen
        Me.Label7.Location = New System.Drawing.Point(207, 186)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(130, 21)
        Me.Label7.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.ForestGreen
        Me.Label6.Location = New System.Drawing.Point(193, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(111, 23)
        Me.Label6.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.ForestGreen
        Me.Label5.Location = New System.Drawing.Point(366, 26)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(106, 22)
        Me.Label5.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.ForestGreen
        Me.Label4.Location = New System.Drawing.Point(24, 153)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(133, 21)
        Me.Label4.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.ForestGreen
        Me.Label3.Location = New System.Drawing.Point(193, 153)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(111, 21)
        Me.Label3.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(64, 106)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(116, 20)
        Me.Label2.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(7, 74)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(23, 100)
        Me.Label1.TabIndex = 0
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(513, -2)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(142, 35)
        Me.AxWindowsMediaPlayer1.TabIndex = 41
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(468, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(138, 24)
        Me.MenuStrip1.TabIndex = 42
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(38, 20)
        Me.FileToolStripMenuItem.Text = "file "
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.OpenToolStripMenuItem.Text = "open"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(664, 510)
        Me.Controls.Add(Me.Panel1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "maze"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents finish As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog

End Class
